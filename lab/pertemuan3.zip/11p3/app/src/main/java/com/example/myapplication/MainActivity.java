package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Persegi psg=new Persegi(12,20);
        //psg.hitungBidang();

        //Lingkaran lnk=new Lingkaran(20);
        //lnk.hitungBidang();

        ArrayList<BidangDatar> bidang = new ArrayList<>();
        bidang.add(new Persegi(10,5));
        bidang.add(new Persegi(5,7));
        bidang.add(new Lingkaran(9));
        bidang.add(new Lingkaran(3));
        bidang.add(new Lingkaran(10));

        for (BidangDatar bid : bidang){
            Log.d(BidangDatar.TAG,"=======================");
            bid.hitungBidang();
        }
    }
}