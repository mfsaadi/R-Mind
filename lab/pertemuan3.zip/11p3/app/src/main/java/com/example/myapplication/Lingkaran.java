package com.example.myapplication;

import android.util.Log;

public class Lingkaran extends BidangDatar{

    int diameter;

    public Lingkaran(int diameter){
        this.namaBidang = "Lingkaran";
        this.diameter = diameter;
    }

    @Override
    public double getLuas() {
        luas = Math.PI * Math.pow(diameter/2,2);
        return luas;
    }

    @Override
    public double getKeliling() {
        keliling = 2*Math.PI *(diameter/2);
        return keliling;
    }

    @Override
    public void properti() {
        Log.d(BidangDatar.TAG,"dengan diameter : "+diameter);
    }
}
