package com.example.myapplication;

import android.util.Log;

public abstract class BidangDatar {
    public static final String TAG = "bidang";

    protected String namaBidang;
    protected double luas,keliling;

    abstract public double getLuas();

    abstract public double getKeliling();

    abstract public void properti();

    public void hitungBidang(){
        Log.d(TAG, "Nama Bidang : "+namaBidang);
        properti();
        Log.d(TAG, "Luasnya : "+getLuas());
        Log.d(TAG, "Kelilingnya : "+getKeliling());
    }

}
