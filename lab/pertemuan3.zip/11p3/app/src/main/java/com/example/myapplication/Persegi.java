package com.example.myapplication;

import android.util.Log;

public class Persegi extends BidangDatar{

    int panjang,lebar;

    public Persegi(int panjang, int lebar){
        namaBidang = "Persegi";
        this.panjang = panjang;
        this.lebar = lebar;
    }

    public double getLuas(){
        luas=panjang*lebar;
        return luas;
    }

    public double getKeliling(){
        keliling = 2* (panjang+lebar);
        return keliling;
    }

    @Override
    public void properti() {
        Log.d(BidangDatar.TAG,"dengan panjang : "+panjang+" dan lebar : "+lebar);

    }
}
